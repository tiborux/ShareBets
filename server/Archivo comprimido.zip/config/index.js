module.exports.env = require('./env.json');
module.exports.database = require('./database.js');
