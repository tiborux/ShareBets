export class User {
    constructor(
        public usuario: string, 
        public password:string,
        public email: string, 
        public nombre:string,
        public apellidos: string,
        public paypal: string
        ){}
}