export class Login {
    constructor(
        public usuario: string, 
        public password:string
        ){}
}